<?php

function is_logged_in() {
  return true; // @todo update this
}

function is_admin() {
  return true; // @todo update this
}
