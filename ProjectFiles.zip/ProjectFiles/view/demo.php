<?php

if (!is_logged_in() || !is_admin()) {
  die("You cannot access this page");
}

?>
Hi admin
