<?php  include '../util/main.php'; ?>
<?php  include '../view/header.php'; ?>
<div id="content">
    <h1>Admin Menu</h1>
    <p><a href="product">Product Manager</a></p>
</div>
<?php include '../view/footer.php'; ?>
