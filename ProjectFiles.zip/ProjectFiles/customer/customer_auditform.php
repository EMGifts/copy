<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>customer_audit</title>
  </head>
  <body>
<div id="register-modal" class="modal">
    <form class="modal-content animate" action="customer_audit.php" method="POST">
      <div class="imgcontainer">
        <span onclick="document.getElementById('register-modal').style.display='none'" class="close" title="Close Modal">x</span>
        <img src="images/img_avatar2.png" alt="Avatar" class="avatar">
      </div>
      <center> <h2> Edit My Account </h2> </center>
      <div class="container">

        <label for="fname"><b>Customer ID</b></label>
        <input type="text" name="customerID" placeholder="customerID" required/>

          <label for="fname"><b>First Name</b></label>
          <input type="text" name="firstName" placeholder="First Name" required/>

          <label for="lname"><b>Last Name</b></label>
          <input type="text" name="lastName" placeholder="Last Name" required/>

          <label for="email"><b>Email</b></label>
          <input type="text" name="emailAddress" placeholder="example@gmail.com" required/>

          <label for="shippingAddress"><b>Shipping Address</b></label>
          <input type="text" name="shipAddress" placeholder="Shipping Address" required/>

          <label for="billingAdress"><b>Billing Address</b></label>
          <input type="text" name="billingAddress" placeholder="Billing Address" required/>

      <button type="submit" name="customer_audit" value="customer_audit">Submit Changes</button>
      </div>
    </form>
  </div>
</body>
</html>
