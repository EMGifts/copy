<?php
    // Parse data
    $category_id = $product['categoryID'];
    $product_code = $product['productCode'];
    $product_name = $product['productName'];
    $description = $product['description'];
    $list_price = $product['listPrice'];
    $discount_percent = $product['discountPercent'];

    // Add HMTL tags to the description
    $description = add_tags($description);

    // Calculate discounts
    $discount_amount = round($list_price * ($discount_percent / 100), 2);
    $unit_price = $list_price - $discount_amount;

    // Format discounts
    $discount_percent = number_format($discount_percent, 0);
    $discount_amount = number_format($discount_amount, 2);
    $unit_price = number_format($unit_price, 2);

    // Get image URL and alternate text
    $image_filename = $product_code . '_m.png';
    $image_path = $app_path . 'images/' . $image_filename;
    $image_alt = 'Image filename: ' . $image_filename;
?>

<h1><?php echo $product_name; ?></h1>
<div id="left_column">
    <p><img class="product" src="<?php echo $image_path; ?>"
            alt="<?php echo $image_alt; ?>" /></p>
</div>

<div id="right_column">
    <p><b>List Price:</b>
        <?php echo '$' . $list_price; ?></p>
    <p><b>Discount:</b>
        <?php echo $discount_percent . '%'; ?></p>
    <p><b>Your Price:</b>
        <?php echo '$' . $unit_price; ?>
        (You save
        <?php echo '$' . $discount_amount; ?>)</p>
    <form action="<?php echo $app_path . 'cart' ?>" method="post">
        <input type="hidden" name="action" value="add" />
        <input type="hidden" name="product_id"
               value="<?php echo $product_id; ?>" />
        <b>Quantity:</b>
        <input type="text" name="quantity" value="1" size="2" />
        <input type="submit" name="add_to_cart" value="Add to Cart" />
    </form>
    <h2>Description</h2>
    <?php echo $description; ?>
</div>


<?php
//session_start();
$_SESSION['isLoggedIn'] = false;

 try{
$connect = mysqli_connect("localhost", "eunice", "eunice", "i_gifts");
}
catch (PDOException $e)
{
  $error = 'Unable to connect to the database server.';
  include 'error.html.php';
  exit();
}


if(isset($_POST["add_to_cart"]))
{
  if(isset($_SESSION["shopping_cart"]))
  {
       $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
       if(!in_array($_GET["id"], $item_array_id))
       {
            $count = count($_SESSION["shopping_cart"]);
            $item_array = array(
                 'item_id' => $_GET["id"],
                 'item_name' => $_POST["hidden_name"],
                 'item_price' => $_POST["hidden_price"],
                 'item_quantity' => $_POST["quantity"]
            );
            $_SESSION["shopping_cart"][$count] = $item_array;
       }
       else
       {
            echo '<script>alert("Item Already Added")</script>';
       }
  }
  else
  {
       $item_array = array(
            'item_id' =>  $_GET["id"],
            'item_name' => $_POST["hidden_name"],
            'item_price' => $_POST["hidden_price"],
            'item_quantity' => $_POST["quantity"]
       );
       $_SESSION["shopping_cart"][0] = $item_array;
  }
}
if(isset($_GET["action"]))
{
  if($_GET["action"] == "delete")
  {
       foreach($_SESSION["shopping_cart"] as $keys => $values)
       {
            if($values["item_id"] == $_GET["id"])
            {
                 unset($_SESSION["shopping_cart"][$keys]);
                 echo '<script>alert("Item Removed")</script>';
            }
       }
  }
}
?>
<!DOCTYPE html>
<html>
  <head>
       <title>Shopping Cart</title>
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  </head>
  <body>
       <div class="container" style="width:1000px;">
            <h3 align="center">Shopping Cart</h3><br />
            <h3>Order Details</h3>
            <div class="table-responsive">
                 <table class="table table-bordered">
                      <tr>
                           <th width="40%">Item Name</th>
                           <th width="10%">Quantity</th>
                           <th width="20%">Price</th>
                           <th width="15%">Total</th>
                           <th width="5%">Action</th>
                      </tr>

                      <?php
                      if(!empty($_SESSION["shopping_cart"]))
                      {
                           $total = 0;
                           foreach($_SESSION["shopping_cart"] as $keys => $values)
                           {
                      ?>
                      <tr>
                           <td><?php echo $values["item_name"]; ?></td>
                           <td><?php echo $values["item_quantity"]; ?></td>
                           <td>$ <?php echo $values["item_price"]; ?></td>
                           <td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>
                           <td><a href="?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>
                      </tr>
                      <?php
                                $total = $total + ($values["item_quantity"] * $values["item_price"]);
                           }
                      ?>

                      <tr>
                           <td colspan="3" align="right">Total</td>
                           <td align="right">$ <?php echo number_format($total, 2); ?></td>
                           <td></td>
                      </tr>
                      <?php
                      }
                      ?>
                 </table>
            </div>

            <?php
            $query = "SELECT * FROM products ORDER BY productID ASC";
            $result = mysqli_query($connect, $query);
            if(mysqli_num_rows($result) > 0)
            {
                 while($row = mysqli_fetch_array($result))
                 {
            ?>
            <div class="col-md-3">
                 <form method="post" action="Shop.php?action=add&id=<?php echo $row["productID"]; ?>">
                      <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
                          <!--image-->
                           <img src="" class="img-responsive" /><br />
                           <h4 class="text-info"><?php echo $row["productName"]; ?></h4>
                           <h4 class="text-danger">$ <?php echo $row["listPrice"]; ?></h4>
                           <input type="text" name="quantity" class="form-control" value="1" />
                           <input type="hidden" name="hidden_name" value="<?php echo $row["productName"]; ?>" />
                           <input type="hidden" name="hidden_price" value="<?php echo $row["listPrice"]; ?>" />
                           <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />
                      </div>
                 </form>
            </div>
            <?php
                 }
            }
            ?>
            <div style="clear:both"></div>
            <br />

  </body>
</html>
