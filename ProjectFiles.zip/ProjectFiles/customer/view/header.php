<!DOCTYPE html>
<html lang="en">

  <head>
    <base href="../">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ideal Gifts</title>

    <!-- Bootstrap core CSS -->
    <link href="../Style/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="../Style/css/one-page-wonder.min.css" rel="stylesheet">
    <link href="../Style/css/login.css" rel="stylesheet">
    <link href="../Style/css/personal.css" rel="stylesheet">
    <!-- Bootstrap core JavaScript -->
    <script src="../Style/vendor/jquery/jquery.min.js"></script>
    <script src="../Style/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
                  <div class="container">
                    <a class="navbar-brand" href="#">Ideal Gifts </a>
                    <!-- Having navig responsive by creating a button-->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                      <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <button class="nav-link" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><a href="<?php echo $app_path. 'customer/homepage.php'; ?>">Home</a></button>
            </li>
            <li class="nav-item">
                <button class="nav-link" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><a href="<?php echo $app_path. 'customer/customer_audit.php'; ?>">Edit Account</a></button>
            </li>
            <!-- display links for all categories -->
              <?php foreach ($categories as $category) : ?>
              <li class="nav-item">
                <button class="nav-link" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">
                  <a href="<?php echo $app_path .
                      'customer/catalog?action=list_products' .
                      '&amp;category_id=' . $category['categoryID']; ?>">
                      <?php echo $category['categoryName']; ?>
                  </a>
            </button>
              </li>
            <?php endforeach; ?>


              </ul>
          </div>
        </div>
      </div>
    </nav>
          <div id="main">
