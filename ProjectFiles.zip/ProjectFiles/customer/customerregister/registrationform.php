<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Register</title>
  </head>
  <body>
    <p>
	  </div>
				<form action="" method="post" >
					<table align="center" width="750">
						<tr align="center">
							<td colspan="6"><h2>Create an Account</h2></td>
						</tr>
						<tr>
							<td align="right"> First Name :</td>
							<td><input type="text" name="firstName" placeholder="First Name..." required/></td>
						</tr>
						<tr>
							<td align="right"> Last Name:</td>
							<td><input type="text" name="lastName" placeholder="Last Name..." required/></td>
						</tr>
						<tr>
							<td align="right"> Email:</td>
							<td><input type="text" name="emailAddress" placeholder="email..."required/></td>
						</tr>
						<tr>
							<td align="right">Password:</td>
							<td><input type="password" name="password" placeholder="Password..."required/></td>
						</tr>
						<tr>
							<td align="right">Re-enter Password:</td>
							<td><input type="password" name="rpassword" placeholder="Password..."required/></td>
						</tr>
						<tr>
							<td align="right">Shipping Address:</td>
							<td><input type="text" name="shipAddress" placeholder="Shipping Address..." required/></td>
						</tr>
						<tr>
							<td align="right">Billing Address:</td>
							<td><input type="text" name="billingAddress" placeholder="Billing Address..." required/></td>
						</tr>


					<tr align="center">
						<td colspan="6"><input type="submit" name="register" value="Create Account" /></td>
					</tr>
					</table>				
				</form>
			</div>
		</div>
	</div>
</body>
</html>
