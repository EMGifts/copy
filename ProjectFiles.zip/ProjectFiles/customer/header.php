<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <base href="../">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ideal Gifts</title>

    <!-- Bootstrap core CSS -->
    <link href="Style/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="Style/css/one-page-wonder.min.css" rel="stylesheet">
    <link href="Style/css/login.css" rel="stylesheet">
  </head>

  <body>

    <!-- Navigation -->
          <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
                <div class="container">
                  <a class="navbar-brand" href="#">Ideal Gifts </a>
                  <!-- Having navig responsive by creating a button-->
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <button class="nav-link" onclick="document.getElementById('register-modal').style.display='block'" style="width:auto;">Sign Up</button>
            </li>
            <li class="nav-item">
              <button class="nav-link" onclick="document.getElementById('login-modal').style.display='block'" style="width:auto;">Log In</button>
            </li>

            <li class="nav-item">
              <button class="nav-link" onclick="document.getElementById('admin-modal').style.display='block'" style="width:auto;">Admin</button>
            </li>
            <!-- Loggin -->
            <div id="login-modal" class="modal">
                <form class="modal-content animate" action="customer/customerlogin/index.php" method="POST">
                  <div class="imgcontainer">
                    <span onclick="document.getElementById('login-modal').style.display='none'" class="close" title="Close Modal">x</span>
                    <img src="images/img_avatar2.png" alt="Avatar" class="avatar">
                  </div>
                  <center> <h2> Log In </h2> </center>
                  <div class="container">
                    <label for="uname"><b>Username</b></label>
                    <input type="text" placeholder="Enter Email" name="emailAddress" required>

                    <label for="psw"><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="password" required>

                    <button type="submit" name="login">Login</button>
                  </div>
                </form>
              </div>

            <!-- Register -->
            <div id="register-modal" class="modal">
                <form class="modal-content animate" action="customer/customerregister/index.php" method="POST">
                  <div class="imgcontainer">
                    <span onclick="document.getElementById('register-modal').style.display='none'" class="close" title="Close Modal">x</span>
                    <img src="images/img_avatar2.png" alt="Avatar" class="avatar">
                  </div>
                  <center> <h2> Create Account </h2> </center>
                  <div class="container">
        							<label for="fname"><b>First Name</b></label>
        							<input type="text" name="firstName" placeholder="First Name" required/>

                      <label for="lname"><b>Last Name</b></label>
        							<input type="text" name="lastName" placeholder="Last Name" required/>

                      <label for="email"><b>Email</b></label>
        							<input type="text" name="emailAddress" placeholder="example@gmail.com" required/>

                      <label for="pass"><b>Password</b></label>
        							<input type="password" name="password" placeholder="Password" required/>

                      <label for="rpass"><b>Re-enter Password</b></label>
                      <input type="password" name="rpassword" placeholder="Password" required/>

                      <label for="shippingAddress"><b>Shipping Address</b></label>
                      <input type="text" name="shipAddress" placeholder="Shipping Address" required/>

                      <label for="billingAdress"><b>Billing Address</b></label>
                      <input type="text" name="billingAddress" placeholder="Billing Address" required/>

                  <button type="submit" name="register" value="Create Account">Create Account</button>
                  </div>
                </form>
              </div>

            <!--admin login -->
            <div id="admin-modal" class="modal">
              <form class="modal-content animate" action="admin/product/index.php" method="POST">
                <div class="imgcontainer">
                  <span onclick="document.getElementById('admin-modal').style.display='none'" class="close" title="Close Modal">x</span>
                  <img src="images/img_avatar2.png" alt="Avatar" class="avatar">
                </div>
                <center> <h2> Admin Log In </h2> </center>
                  <div class="container">
                    <label for="uname"><b>Username</b></label>
                    <input type="text" placeholder="Enter Email" name="emailAddress" required>
                    <label for="psw"><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="password" required>
                    <!-- button to click result -->
                    <button type="submit" name="login">Login</button>
                  </div>
                </form>
              </div>
            </ul>
          </div>
        </nav>

    <header class="masthead text-center text-white">
      <div class="masthead-content">
        <div class="container">
          <h1 class="masthead-heading mb-0">Gifts For All</h1>
          <h2 class="masthead-subheading mb-0">Beautiful, Economic, Special</h2>
          <a href="customer/header.php" class="btn btn-primary btn-xl rounded-pill mt-5">Must sign in to shop</a>
        </div>
      </div>
      <div class="bg-circle-1 bg-circle"></div>
      <div class="bg-circle-2 bg-circle"></div>
      <div class="bg-circle-3 bg-circle"></div>
      <div class="bg-circle-4 bg-circle"></div>
    </header>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 order-lg-2">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="images/01.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="p-5">
              <h2 class="display-4">For those into Flowers</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod aliquid, mollitia odio veniam sit iste esse assumenda amet aperiam exercitationem, ea animi blanditiis recusandae! Ratione voluptatum molestiae adipisci, beatae obcaecati.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="images/02.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6">
            <div class="p-5">
              <h2 class="display-4">For those into Food</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod aliquid, mollitia odio veniam sit iste esse assumenda amet aperiam exercitationem, ea animi blanditiis recusandae! Ratione voluptatum molestiae adipisci, beatae obcaecati.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 order-lg-2">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="images/03.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="p-5">
              <h2 class="display-4">For those into TeddyBears</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod aliquid, mollitia odio veniam sit iste esse assumenda amet aperiam exercitationem, ea animi blanditiis recusandae! Ratione voluptatum molestiae adipisci, beatae obcaecati.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">Copyright &copy; <?php echo date("Y"); ?> Ideal Gifts </p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="Style/vendor/jquery/jquery.min.js"></script>
    <script src="Style/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>
  </html>
