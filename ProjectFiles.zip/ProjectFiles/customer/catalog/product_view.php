<?php include '../view/header.php'; ?>
<div id="content">
    <!-- display product -->
    <?php include '../view/product.php'; ?>
</div>
<?php include '../view/footer.php'; ?>
