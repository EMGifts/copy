<?php

try
{

  $pdo = new PDO('mysql:host=localhost;dbname=i_gifts', 'eunice', 'eunice');
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $pdo->exec('SET NAMES "utf8"');
}
catch (PDOException $e)
{
  $error = 'Unable to connect to the database server.';
  include 'error.html.php';
  exit();
}

  if(isset($_POST['customer_audit']))
	{
		//retrieve customer info
		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		$emailAddress = $_POST['emailAddress'];
		$shipAddress = $_POST['shipAddress'];
		$billingAddress = $_POST['billingAddress'];
    $customerID = $_POST['customerID'];
    //$plainTextPassword = $_POST['password'];


			$sql = "UPDATE CUSTOMERS SET
						firstName = :firstName,
						lastName = :lastName,
						emailAddress = :emailAddress,
						shipAddress = :shipAddress,
						billingAddress = :billingAddress,
            customerID = :customerID
            WHERE emailAddress=:emailAddress";

			$s = $pdo->prepare($sql);
			$s->bindValue(':firstName', $_POST['firstName']);
			$s->bindValue(':lastName', $_POST['lastName']);
			$s->bindValue(':emailAddress', $_POST['emailAddress']);
			$s->bindValue(':shipAddress', $_POST['shipAddress']);
			$s->bindValue(':billingAddress', $_POST['billingAddress']);
      $s->bindValue(':customerID', $_POST['customerID']);
			$s->execute();
		
    }


  include 'customer_auditform.php';
